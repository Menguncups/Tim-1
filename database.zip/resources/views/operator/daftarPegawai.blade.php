<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pegawai</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- DataTables + Bootstrap 5 -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap5.min.css">

    <!-- Sidebar CSS -->
    <link rel="stylesheet" href="{{ asset('css/operatorSidebar.css') }}">
    <!-- Page CSS -->
    <link rel="stylesheet" href="{{ asset('css/operator.css') }}">
</head>

<body>

    <button class="mobile-toggle" id="sidebarToggle">
        <i class="bi bi-list"></i>
    </button>

    <div class="wrapper">

        {{-- SIDEBAR --}}
        @include('Sidebar.operatorSidebar')

        {{-- CONTENT --}}
        <div class="content-area">

            <!-- PAGE HEADER -->
            <div class="du-page-header">
                <div>
                    <h4 class="du-page-title">Daftar Pengguna</h4>
                    <p class="du-page-sub">Kelola seluruh akun pengguna sistem</p>
                </div>
                <a href="#" class="btn-du-tambah">
                    <i class="bi bi-person-plus-fill"></i>
                    Tambah Pengguna
                </a>
            </div>

            {{-- <!-- STAT CHIPS -->
            <div class="du-chips">
                <div class="du-chip">
                    <i class="bi bi-star-fill" style="color:#e74c3c"></i>
                    <span class="du-chip-num">3</span>
                    <span class="du-chip-lbl">Pimpinan</span>
                </div>
                <div class="du-chip">
                    <i class="bi bi-person-video3" style="color:#2980b9"></i>
                    <span class="du-chip-num">24</span>
                    <span class="du-chip-lbl">Dosen</span>
                </div>
                <div class="du-chip">
                    <i class="bi bi-people-fill" style="color:#27ae60"></i>
                    <span class="du-chip-num">12</span>
                    <span class="du-chip-lbl">Tendik</span>
                </div>
                <div class="du-chip">
                    <i class="bi bi-shield-fill" style="color:#8e44ad"></i>
                    <span class="du-chip-num">5</span>
                    <span class="du-chip-lbl">Operator</span>
                </div>
            </div> --}}

            <!-- FILTER PILLS -->
            <div class="du-filter-bar">
                <button class="du-pill active" data-tab="semua">Semua</button>
                <button class="du-pill" data-tab="pimpinan">
                    <i class="bi bi-star-fill"></i> Pimpinan
                </button>
                <button class="du-pill" data-tab="dosen">
                    <i class="bi bi-person-video3"></i> Dosen
                </button>
                <button class="du-pill" data-tab="tendik">
                    <i class="bi bi-people-fill"></i> Tendik
                </button>
                <button class="du-pill" data-tab="operator">
                    <i class="bi bi-shield-fill"></i> Operator
                </button>
            </div>

            <!-- TABLE -->
            <div class="du-table-wrap">
                <table id="tabelPengguna" class="display w-100">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Pengguna</th>
                            <th>NIP</th>
                            <th>Prodi</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($pegawai as $p)
                            <tr data-role="{{ $p->roles->pluck('nama_role')->implode(' ') }}">
                                <td>{{ $loop->iteration }}</td>

                                <td>
                                    <div>
                                        <div class="du-user-name">{{ $p->nama }}</div>
                                        <div class="du-user-email">{{ $p->email }}</div>
                                    </div>
                                </td>

                                <td class="du-nip">{{ $p->nip }}</td>

                                <td>{{ $p->homebase }}</td>

                                <td>
                                    @foreach ($p->roles as $role)
                                        @php
                                            $roleName = strtolower($role->nama_role);
                                        @endphp

                                        <span class="du-badge du-badge-{{ $roleName }}">
                                            {{ $role->nama_role }}
                                        </span>
                                    @endforeach
                                </td>

                                <td>
                                    <span class="du-status du-status-on">Aktif</span>
                                </td>

                                <td class="text-center">
                                    <div class="du-actions">
                                        <a href="#" class="du-act du-act-view" title="Detail">
                                            <i class="bi bi-eye-fill"></i>
                                        </a>

                                        <a href="#" class="du-act du-act-edit" title="Edit">
                                            <i class="bi bi-pencil-fill"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

        </div>{{-- end content-area --}}
    </div>{{-- end wrapper --}}

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap5.min.js"></script>

    <!-- Sidebar JS -->
    <script src="{{ asset('js/operatorSideBar.js') }}"></script>
    <!-- Page JS -->
    <script src="{{ asset('js/operator.js') }}"></script>
</body>

</html>
