/* ================================================
   daftarPengguna.js
   Filter pill & DataTable untuk Daftar Pengguna
   ================================================ */

$(document).ready(function () {
    // ── 1. INISIALISASI DATATABLE ─────────────────────────────────
    const table = $("#tabelPengguna").DataTable({
        language: {
            search: "",
            searchPlaceholder: "Cari nama, NIP, email...",
            lengthMenu: "Tampilkan _MENU_ data",
            info: "Menampilkan _START_–_END_ dari _TOTAL_ pengguna",
            infoEmpty: "Tidak ada data",
            infoFiltered: "(difilter dari _MAX_ total)",
            paginate: { first: "«", last: "»", next: "›", previous: "‹" },
            emptyTable: "Tidak ada data pengguna",
            zeroRecords: "Data tidak ditemukan",
        },
        pageLength: 10,
        lengthMenu: [5, 10, 25, 50],
        order: [[0, "asc"]],
        columnDefs: [
            { width: "55px", targets: 0 },
            { orderable: false, targets: [4, 6] },
            { searchable: false, targets: [5, 6] },
        ],
        // DOM: posisi elemen DataTables
        dom: '<"du-dt-top"lf>rt<"du-dt-bot"ip>',
        drawCallback: function () {
            // Reapply filter setelah redraw (misal setelah search)
            const activeTab = $(".du-pill.active").data("tab");
            if (activeTab && activeTab !== "semua") {
                filterByRole(activeTab);
            }
        },
    });

    // ── 2. FILTER PILL ────────────────────────────────────────────
    function filterByRole(tab) {
        if (tab === "semua") {
            // Tampilkan semua baris
            $.fn.dataTable.ext.search.pop();
            table.draw();
            return;
        }

        // Push custom search function
        $.fn.dataTable.ext.search.pop(); // buang filter sebelumnya
        $.fn.dataTable.ext.search.push(function (settings, data, dataIndex) {
            const row = table.row(dataIndex).node();
            const roleAttr = $(row).data("role") || "";
            return roleAttr.split(" ").includes(tab);
        });
        table.draw();
    }

    $(".du-pill").on("click", function () {
        $(".du-pill").removeClass("active");
        $(this).addClass("active");

        const tab = $(this).data("tab");
        filterByRole(tab);
    });

    // ── 3. CUSTOM SEARCH INPUT STYLE ─────────────────────────────
    // Tambahkan ikon search di dalam input (setelah DataTable render)
    setTimeout(function () {
        const $input = $(".dataTables_filter input");
        $input.attr("placeholder", "Cari nama, NIP, email...");
    }, 100);
});
