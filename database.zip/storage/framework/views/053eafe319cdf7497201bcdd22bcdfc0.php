<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pegawai</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('css/operatorSidebar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/createPegawai.css')); ?>">
</head>

<body>

    <button class="mobile-toggle" id="sidebarToggle">
        <i class="bi bi-list"></i>
    </button>

    <div class="wrapper">

        <?php echo $__env->make('Sidebar.operatorSidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="content-col">
            <main class="content-area">

                <div class="page-header mb-4">
                    <div class="d-flex align-items-center gap-3">
                        <div class="header-icon">
                            <i class="bi bi-person-plus-fill"></i>
                        </div>
                        <div>
                            <h4 class="page-title mb-0">Tambah Pegawai</h4>
                            <p class="page-sub mb-0">Lengkapi informasi data pegawai baru</p>
                        </div>
                    </div>
                </div>

                <div class="form-card">

                    <div class="card-header-strip">
                        <i class="bi bi-pencil-square me-2"></i>Form Input Data Pegawai
                    </div>

                    <form id="formData"
                        action="<?php echo e(url('/operator/tambah-data')); ?>"
                        method="POST"
                        enctype="multipart/form-data"
                        class="form-body">
                        <?php echo csrf_field(); ?>

                        <?php if($errors->any()): ?>
                            <div class="alert-error-box">
                                <strong>Data belum berhasil disimpan.</strong>
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="field-group d-flex flex-column align-items-center mb-4">
                            <label class="field-label" for="foto">
                                <i class="bi bi-camera me-1"></i>Upload Pas Foto
                                <span class="required-dot">*</span>
                            </label>

                            <div class="foto-upload-wrap">
                                <label class="foto-upload-label" for="foto">
                                    <div class="foto-placeholder" id="fotoPlaceholder">
                                        <i class="bi bi-person-bounding-box"></i>
                                        <span>Klik untuk upload foto</span>
                                        <small>JPG / PNG, maks. 2 MB</small>
                                    </div>

                                    <img id="fotoPreview"
                                        class="foto-preview"
                                        src=""
                                        alt="Preview Foto"
                                        style="display:none;">
                                </label>

                                <input type="file"
                                    id="foto"
                                    name="foto"
                                    class="d-none"
                                    accept="image/png, image/jpeg">

                                <button type="button" id="fotoHapus" class="foto-hapus-btn" style="display:none;">
                                    <i class="bi bi-x-circle-fill me-1"></i>Hapus Foto
                                </button>
                            </div>

                            <span id="error_foto" class="field-error">
                                <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                        </div>

                        <div class="field-group mb-4">
                            <label class="field-label">
                                <i class="bi bi-person-badge me-1"></i>Role Pegawai
                                <span class="required-dot">*</span>
                            </label>

                            <div class="role-selector">

                                <label class="role-card" data-role="dosen" data-group="A">
                                    <input type="checkbox"
                                        name="roles[]"
                                        value="dosen"
                                        class="role-checkbox"
                                        <?php echo e(in_array('dosen', old('roles', [])) ? 'checked' : ''); ?>>

                                    <div class="role-card-icon">
                                        <i class="bi bi-mortarboard-fill"></i>
                                    </div>

                                    <div class="role-card-body">
                                        <div class="role-card-title">Dosen</div>
                                        <div class="role-card-desc">Memiliki NIDN</div>
                                    </div>

                                    <div class="role-check">
                                        <i class="bi bi-check-lg"></i>
                                    </div>
                                </label>

                                <label class="role-card" data-role="pimpinan" data-group="A">
                                    <input type="checkbox"
                                        name="roles[]"
                                        value="pimpinan"
                                        class="role-checkbox"
                                        <?php echo e(in_array('pimpinan', old('roles', [])) ? 'checked' : ''); ?>>

                                    <div class="role-card-icon">
                                        <i class="bi bi-person-workspace"></i>
                                    </div>

                                    <div class="role-card-body">
                                        <div class="role-card-title">Pimpinan</div>
                                        <div class="role-card-desc">Bisa bersama Dosen</div>
                                    </div>

                                    <div class="role-check">
                                        <i class="bi bi-check-lg"></i>
                                    </div>
                                </label>

                                <label class="role-card" data-role="operator" data-group="B">
                                    <input type="checkbox"
                                        name="roles[]"
                                        value="operator"
                                        class="role-checkbox"
                                        <?php echo e(in_array('operator', old('roles', [])) ? 'checked' : ''); ?>>

                                    <div class="role-card-icon">
                                        <i class="bi bi-pc-display"></i>
                                    </div>

                                    <div class="role-card-body">
                                        <div class="role-card-title">Operator</div>
                                        <div class="role-card-desc">Tidak memakai NIDN</div>
                                    </div>

                                    <div class="role-check">
                                        <i class="bi bi-check-lg"></i>
                                    </div>
                                </label>

                                <label class="role-card" data-role="tendik" data-group="B">
                                    <input type="checkbox"
                                        name="roles[]"
                                        value="tendik"
                                        class="role-checkbox"
                                        <?php echo e(in_array('tendik', old('roles', [])) ? 'checked' : ''); ?>>

                                    <div class="role-card-icon">
                                        <i class="bi bi-people-fill"></i>
                                    </div>

                                    <div class="role-card-body">
                                        <div class="role-card-title">Tendik</div>
                                        <div class="role-card-desc">Bisa bersama Operator</div>
                                    </div>

                                    <div class="role-check">
                                        <i class="bi bi-check-lg"></i>
                                    </div>
                                </label>

                            </div>

                            <div class="role-info">
                                Boleh pilih 1 role. Jika pilih 2 role, hanya boleh:
                                <b>Dosen + Pimpinan</b> atau <b>Operator + Tendik</b>.
                            </div>

                            <span id="error_role" class="field-error">
                                <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                        </div>

                        <div class="row g-4">

                            <div class="col-md-6">

                                <div class="field-group">
                                    <label class="field-label" for="nama">
                                        <i class="bi bi-person me-1"></i>Nama Lengkap
                                        <span class="required-dot">*</span>
                                    </label>

                                    <input type="text"
                                        id="nama"
                                        name="nama"
                                        class="field-input"
                                        value="<?php echo e(old('nama')); ?>"
                                        placeholder="Masukkan nama lengkap">

                                    <span id="error_nama" class="field-error">
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="field-group">
                                    <label class="field-label" for="email">
                                        <i class="bi bi-envelope me-1"></i>Email
                                        <span class="required-dot">*</span>
                                    </label>

                                    <input type="email"
                                        id="email"
                                        name="email"
                                        class="field-input"
                                        value="<?php echo e(old('email')); ?>"
                                        placeholder="contoh@unri.ac.id">

                                    <span id="error_email" class="field-error">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="field-group">
                                    <label class="field-label" for="password">
                                        <i class="bi bi-lock me-1"></i>Password
                                        <span class="required-dot">*</span>
                                    </label>

                                    <div class="password-wrapper">
                                        <input type="password"
                                            id="password"
                                            name="password"
                                            class="field-input password-input"
                                            placeholder="Masukkan password">

                                        <button type="button" class="password-toggle" id="togglePassword">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                    </div>

                                    <span id="error_password" class="field-error">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="field-group">
                                    <label class="field-label" for="nip">
                                        <i class="bi bi-card-text me-1"></i>NIP
                                        <span class="required-dot">*</span>
                                    </label>

                                    <input type="text"
                                        id="nip"
                                        name="nip"
                                        class="field-input"
                                        value="<?php echo e(old('nip')); ?>"
                                        placeholder="18 digit NIP"
                                        maxlength="18"
                                        minlength="18"
                                        inputmode="numeric"
                                        pattern="[0-9]{18}">

                                    <span id="error_nip" class="field-error">
                                        <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div id="section_nidn" class="dynamic-section hidden">
                                    <div class="field-group">
                                        <label class="field-label" for="nidn">
                                            <i class="bi bi-upc me-1"></i>NIDN
                                            <span class="required-dot">*</span>
                                        </label>

                                        <input type="text"
                                            id="nidn"
                                            name="nidn"
                                            class="field-input"
                                            value="<?php echo e(old('nidn')); ?>"
                                            placeholder="10 digit NIDN"
                                            maxlength="10"
                                            minlength="10"
                                            inputmode="numeric"
                                            pattern="[0-9]{10}">

                                        <span id="error_nidn" class="field-error">
                                            <?php $__errorArgs = ['nidn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                    </div>
                                </div>

                                <div class="field-group">
                                    <label class="field-label" for="jenis_kelamin">
                                        <i class="bi bi-gender-ambiguous me-1"></i>Jenis Kelamin
                                        <span class="required-dot">*</span>
                                    </label>

                                    <select id="jenis_kelamin"
                                        name="jenis_kelamin"
                                        class="field-input field-select">
                                        <option value="">-- Pilih Jenis Kelamin --</option>
                                        <option value="Laki-laki" <?php echo e(old('jenis_kelamin') == 'Laki-laki' ? 'selected' : ''); ?>>
                                            Laki-laki
                                        </option>
                                        <option value="Perempuan" <?php echo e(old('jenis_kelamin') == 'Perempuan' ? 'selected' : ''); ?>>
                                            Perempuan
                                        </option>
                                    </select>

                                    <span id="error_jk" class="field-error">
                                        <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="field-group">
                                    <label class="field-label" for="tanggal_lahir">
                                        <i class="bi bi-calendar3 me-1"></i>Tanggal Lahir
                                        <span class="required-dot">*</span>
                                    </label>

                                    <input type="date"
                                        id="tanggal_lahir"
                                        name="tanggal_lahir"
                                        class="field-input"
                                        value="<?php echo e(old('tanggal_lahir')); ?>">

                                    <span id="error_tgl" class="field-error">
                                        <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="field-group">
                                    <label class="field-label" for="no_hp">
                                        <i class="bi bi-phone me-1"></i>No. HP
                                        <span class="required-dot">*</span>
                                    </label>

                                    <input type="text"
                                        id="no_hp"
                                        name="no_hp"
                                        class="field-input"
                                        value="<?php echo e(old('no_hp')); ?>"
                                        placeholder="Contoh: 08123456789">

                                    <span id="error_hp" class="field-error">
                                        <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="field-group">
                                    <label class="field-label" for="no_hp_darurat">
                                        <i class="bi bi-phone-vibrate me-1"></i>No. HP Darurat
                                    </label>

                                    <input type="text"
                                        id="no_hp_darurat"
                                        name="no_hp_darurat"
                                        class="field-input"
                                        value="<?php echo e(old('no_hp_darurat')); ?>"
                                        placeholder="Contoh: 08123456789">

                                    <span id="error_hp_darurat" class="field-error">
                                        <?php $__errorArgs = ['no_hp_darurat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="field-group">
                                    <label class="field-label" for="homebase">
                                        <i class="bi bi-building me-1"></i>Homebase
                                        <span class="required-dot">*</span>
                                    </label>

                                    <select id="homebase"
                                        name="homebase"
                                        class="field-input field-select">
                                        <option value="">-- Pilih Homebase --</option>

                                        <optgroup label="S1">
                                            <option value="S1 Teknik Sipil" <?php echo e(old('homebase') == 'S1 Teknik Sipil' ? 'selected' : ''); ?>>
                                                S1 Teknik Sipil
                                            </option>
                                            <option value="S1 Teknik Mesin" <?php echo e(old('homebase') == 'S1 Teknik Mesin' ? 'selected' : ''); ?>>
                                                S1 Teknik Mesin
                                            </option>
                                            <option value="S1 Teknik Elektro" <?php echo e(old('homebase') == 'S1 Teknik Elektro' ? 'selected' : ''); ?>>
                                                S1 Teknik Elektro
                                            </option>
                                            <option value="S1 Teknik Kimia" <?php echo e(old('homebase') == 'S1 Teknik Kimia' ? 'selected' : ''); ?>>
                                                S1 Teknik Kimia
                                            </option>
                                            <option value="S1 Teknik Lingkungan" <?php echo e(old('homebase') == 'S1 Teknik Lingkungan' ? 'selected' : ''); ?>>
                                                S1 Teknik Lingkungan
                                            </option>
                                            <option value="S1 Arsitektur" <?php echo e(old('homebase') == 'S1 Arsitektur' ? 'selected' : ''); ?>>
                                                S1 Arsitektur
                                            </option>
                                            <option value="S1 Teknik Informatika" <?php echo e(old('homebase') == 'S1 Teknik Informatika' ? 'selected' : ''); ?>>
                                                S1 Teknik Informatika
                                            </option>
                                        </optgroup>

                                        <optgroup label="D3">
                                            <option value="D3 Teknik Sipil" <?php echo e(old('homebase') == 'D3 Teknik Sipil' ? 'selected' : ''); ?>>
                                                D3 Teknik Sipil
                                            </option>
                                            <option value="D3 Teknik Mesin" <?php echo e(old('homebase') == 'D3 Teknik Mesin' ? 'selected' : ''); ?>>
                                                D3 Teknik Mesin
                                            </option>
                                            <option value="D3 Teknik Elektro" <?php echo e(old('homebase') == 'D3 Teknik Elektro' ? 'selected' : ''); ?>>
                                                D3 Teknik Elektro
                                            </option>
                                            <option value="D3 Teknik Kimia" <?php echo e(old('homebase') == 'D3 Teknik Kimia' ? 'selected' : ''); ?>>
                                                D3 Teknik Kimia
                                            </option>
                                            <option value="D3 Teknologi Pulp dan Kertas" <?php echo e(old('homebase') == 'D3 Teknologi Pulp dan Kertas' ? 'selected' : ''); ?>>
                                                D3 Teknologi Pulp dan Kertas
                                            </option>
                                        </optgroup>
                                    </select>

                                    <span id="error_homebase" class="field-error">
                                        <?php $__errorArgs = ['homebase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="field-group">
                                    <label class="field-label" for="pangkat_golongan">
                                        <i class="bi bi-award me-1"></i>Pangkat / Golongan
                                        <span class="required-dot">*</span>
                                    </label>

                                    <select id="pangkat_golongan"
                                        name="pangkat_golongan"
                                        class="field-input field-select">
                                        <option value="">-- Pilih Pangkat / Golongan --</option>

                                        <option value="II/a - Pengatur Muda" <?php echo e(old('pangkat_golongan') == 'II/a - Pengatur Muda' ? 'selected' : ''); ?>>
                                            II/a - Pengatur Muda
                                        </option>
                                        <option value="II/b - Pengatur Muda Tk. I" <?php echo e(old('pangkat_golongan') == 'II/b - Pengatur Muda Tk. I' ? 'selected' : ''); ?>>
                                            II/b - Pengatur Muda Tk. I
                                        </option>
                                        <option value="II/c - Pengatur" <?php echo e(old('pangkat_golongan') == 'II/c - Pengatur' ? 'selected' : ''); ?>>
                                            II/c - Pengatur
                                        </option>
                                        <option value="II/d - Pengatur Tk. I" <?php echo e(old('pangkat_golongan') == 'II/d - Pengatur Tk. I' ? 'selected' : ''); ?>>
                                            II/d - Pengatur Tk. I
                                        </option>

                                        <option value="III/a - Penata Muda" <?php echo e(old('pangkat_golongan') == 'III/a - Penata Muda' ? 'selected' : ''); ?>>
                                            III/a - Penata Muda
                                        </option>
                                        <option value="III/b - Penata Muda Tk. I" <?php echo e(old('pangkat_golongan') == 'III/b - Penata Muda Tk. I' ? 'selected' : ''); ?>>
                                            III/b - Penata Muda Tk. I
                                        </option>
                                        <option value="III/c - Penata" <?php echo e(old('pangkat_golongan') == 'III/c - Penata' ? 'selected' : ''); ?>>
                                            III/c - Penata
                                        </option>
                                        <option value="III/d - Penata Tk. I" <?php echo e(old('pangkat_golongan') == 'III/d - Penata Tk. I' ? 'selected' : ''); ?>>
                                            III/d - Penata Tk. I
                                        </option>

                                        <option value="IV/a - Pembina" <?php echo e(old('pangkat_golongan') == 'IV/a - Pembina' ? 'selected' : ''); ?>>
                                            IV/a - Pembina
                                        </option>
                                        <option value="IV/b - Pembina Tk. I" <?php echo e(old('pangkat_golongan') == 'IV/b - Pembina Tk. I' ? 'selected' : ''); ?>>
                                            IV/b - Pembina Tk. I
                                        </option>
                                        <option value="IV/c - Pembina Utama Muda" <?php echo e(old('pangkat_golongan') == 'IV/c - Pembina Utama Muda' ? 'selected' : ''); ?>>
                                            IV/c - Pembina Utama Muda
                                        </option>
                                        <option value="IV/d - Pembina Utama Madya" <?php echo e(old('pangkat_golongan') == 'IV/d - Pembina Utama Madya' ? 'selected' : ''); ?>>
                                            IV/d - Pembina Utama Madya
                                        </option>
                                        <option value="IV/e - Pembina Utama" <?php echo e(old('pangkat_golongan') == 'IV/e - Pembina Utama' ? 'selected' : ''); ?>>
                                            IV/e - Pembina Utama
                                        </option>
                                    </select>

                                    <span id="error_pangkat" class="field-error">
                                        <?php $__errorArgs = ['pangkat_golongan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="field-group">
                                    <label class="field-label" for="jabatan_fungsional">
                                        <i class="bi bi-briefcase me-1"></i>Jabatan Fungsional
                                        <span class="required-dot">*</span>
                                    </label>

                                    <select id="jabatan_fungsional"
                                        name="jabatan_fungsional"
                                        class="field-input field-select"
                                        data-old="<?php echo e(old('jabatan_fungsional')); ?>">
                                        <option value="">-- Pilih Jabatan Fungsional --</option>
                                    </select>

                                    <span id="error_jabatan" class="field-error">
                                        <?php $__errorArgs = ['jabatan_fungsional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                            </div>
                        </div>

                        <div class="action-bar mt-4">
                            <span class="required-note">
                                <span class="required-dot">*</span> Wajib diisi
                            </span>

                            <div class="d-flex gap-2">
                                <a href="<?php echo e(url('/operator/daftar-pegawai')); ?>" class="btn-cancel">
                                    <i class="bi bi-arrow-left me-2"></i>Batal
                                </a>

                                <button type="button" id="submit" class="btn-submit">
                                    <i class="bi bi-save2 me-2"></i>Simpan Data
                                </button>
                            </div>
                        </div>

                    </form>
                </div>

            </main>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('js/operatorSideBar.js')); ?>"></script>
    <script src="<?php echo e(asset('js/createPegawai.js')); ?>"></script>

</body>

</html><?php /**PATH D:\Code\tim_1\resources\views/operator/tambahPegawai.blade.php ENDPATH**/ ?>