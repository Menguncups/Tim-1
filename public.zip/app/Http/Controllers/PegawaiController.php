<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class PegawaiController extends Controller
{
    public function index()
    {
        $pegawai = Pegawai::with('roles')->get();

        return view('operator.daftarPegawai', compact('pegawai'));
    }

    public function create()
    {
        return view('operator.tambahPegawai');
    }

    public function store(Request $request)
    {
        $roles = $request->roles ?? [];

        $butuhNidn = in_array('dosen', $roles) || in_array('pimpinan', $roles);

        $validator = Validator::make($request->all(), [
            'foto' => ['required', 'image', 'mimes:jpg,jpeg,png', 'max:2048'],

            'roles' => ['required', 'array', 'min:1', 'max:2'],
            'roles.*' => ['required', 'in:dosen,pimpinan,operator,tendik'],

            'nama' => ['required', 'string', 'max:50', 'regex:/^[^0-9]+$/'],
            'email' => ['required', 'email', 'max:50', 'unique:pegawai,email', 'unique:users,email'],
            'password' => ['required', 'string', 'min:8'],

            'nip' => ['required', 'digits:18', 'unique:pegawai,nip'],

            'nidn' => [
                Rule::requiredIf($butuhNidn),
                'nullable',
                'digits:10',
                'unique:pegawai,nidn',
            ],

            'jenis_kelamin' => ['required', 'in:Laki-laki,Perempuan'],
            'tanggal_lahir' => ['required', 'date'],

            'no_hp' => ['required', 'digits_between:10,14'],
            'no_hp_darurat' => ['nullable', 'digits_between:10,14'],

            'homebase' => ['required', 'string', 'max:80'],
            'pangkat_golongan' => ['required', 'string', 'max:50'],
            'jabatan_fungsional' => ['required', 'string', 'max:50'],
        ]);

        $validator->after(function ($validator) use ($roles) {
            $sortedRoles = $roles;
            sort($sortedRoles);

            if (count($sortedRoles) === 2) {
                $gabungan = implode(',', $sortedRoles);

                $kombinasiValid = [
                    'dosen,pimpinan',
                    'operator,tendik',
                ];

                if (! in_array($gabungan, $kombinasiValid)) {
                    $validator->errors()->add(
                        'roles',
                        'Kombinasi role hanya boleh Dosen + Pimpinan atau Operator + Tendik.'
                    );
                }
            }
        });

        $validated = $validator->validate();

        DB::transaction(function () use ($request, $validated, $butuhNidn) {
            $idPegawai = $this->generateIdPegawai();

            $namaFoto = null;

            if ($request->hasFile('foto')) {
                $folder = public_path('photo');

                if (! file_exists($folder)) {
                    mkdir($folder, 0755, true);
                }

                $file = $request->file('foto');
                $namaFoto = 'foto_'.time().'_'.uniqid().'.'.$file->getClientOriginalExtension();

                $file->move($folder, $namaFoto);
            }

            $pegawai = Pegawai::create([
                'id_pegawai' => $idPegawai,
                'nip' => $validated['nip'],
                'nidn' => $butuhNidn ? $validated['nidn'] : null,
                'nama' => $validated['nama'],
                'jenis_kelamin' => $validated['jenis_kelamin'],
                'tanggal_lahir' => $validated['tanggal_lahir'],
                'no_hp' => $validated['no_hp'],
                'no_hp_darurat' => $validated['no_hp_darurat'] ?? null,
                'homebase' => $validated['homebase'],
                'email' => $validated['email'],
                'pangkat_golongan' => $validated['pangkat_golongan'],
                'jabatan_fungsional' => $validated['jabatan_fungsional'],
                'foto' => $namaFoto,
            ]);

            User::create([
                'name' => $validated['nama'],
                'email' => $validated['email'],
                'password' => Hash::make($validated['password']),
                'pegawai_id_pegawai' => $idPegawai,
            ]);

            $roleIds = Role::query()
                ->whereIn('nama_role', $validated['roles'], 'and', false)
                ->pluck('id_role')
                ->toArray();

            if (count($roleIds) !== count($validated['roles'])) {
                throw ValidationException::withMessages([
                    'roles' => 'Data role belum lengkap di tabel role. Jalankan seeder role terlebih dahulu.',
                ]);
            }

            $pegawai->roles()->sync($roleIds);
        });

        return redirect('/operator/daftar-pegawai')
            ->with('success', 'Data pegawai berhasil ditambahkan.');
    }

    private function generateIdPegawai()
    {
        $lastPegawai = Pegawai::query()
            ->where('id_pegawai', 'like', 'PGW%')
            ->orderByDesc('id_pegawai')
            ->lockForUpdate()
            ->first();

        if (! $lastPegawai) {
            return 'PGW0000001';
        }

        $lastNumber = (int) substr($lastPegawai->id_pegawai, 3);

        return 'PGW'.str_pad($lastNumber + 1, 7, '0', STR_PAD_LEFT);
    }

    public function edit($id)
    {
        $pegawai = Pegawai::findOrFail($id);

        return view('pegawai.edit', compact('pegawai'));
    }

    public function update(Request $request, $id)
    {
        $pegawai = Pegawai::findOrFail($id);

        $pegawai->update($request->all());

        return redirect('/pegawai');
    }

    public function destroy($id)
    {
        Pegawai::destroy($id);

        return redirect('/pegawai');
    }
}
